<?php
$file = file_get_contents($_GET['requrl']);
echo $file;
?>